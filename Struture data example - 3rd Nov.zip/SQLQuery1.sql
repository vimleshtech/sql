

create  database learning;

use learning;


create table users(uid int, name varchar(100), gender varchar(10),
sal int);



select * from users;


insert into users(uid,name,gender,sal)
values(1,'raman','male',333344)

select * from health_data


--projection 
SELECT CHART_ID,PAYMENT,PROVIDER_ADDRESS1 FROM HEALTH_DATA 


SELECT CHART_ID,PAYMENT,PROVIDER_ADDRESS1 FROM HEALTH_DATA 
where payment > 50

--update data 
update HEALTH_DATA
set payment =1000
where chart_id ='8321911701'


--remove row 

delete from  HEALTH_DATA
where chart_id ='8321911701'



select * from health_data 

--alter
alter table health_data
add test_col datetime


--drop column
alter table health_data
drop column provider_address1 


update health_data
set test_col = '2018-01-01'


select chart_id,payment,test_col,provider_address1 from health_data 






/* truncate vs delete
1. delete allow where clause (selected rows can be deleted)
    and all rows can be also delete 

   truncate doesn't allow where calause, only all rows can be deleted



 */

 --is allowed
 truncate table health_data where payment = 50

 --is allowed
 truncate table health_data 
 
delete from health_data where payment = 50
delete from health_data 


--transaction 

begin tran 

--drop object
drop table health_data 

--select * from health_data 


rollback 


--or
commit 
