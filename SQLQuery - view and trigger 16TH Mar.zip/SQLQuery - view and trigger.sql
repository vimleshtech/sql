
use hrms 


select * from employee

alter view v_employee
as
	select * from employee


alter view v_employee2
as
	select fname,lname as fullanme, left(lname,2) as ml from employee



alter table employee 
add country varchar(100)

update employee  set country='india'

alter table employee  
drop column country
--get data fro view
select * from v_employee


insert into v_employee(eid,fname)
values(100,'jatin')

select * from v_employee

update v_employee
set mname ='mname'
where eid  =100

delete from v_employee where eid  =100

select * from v_employee2


insert into v_employee2
values('aaaa','ffff','cc') --will not work 

insert into v_employee2(fname,fullanme)
values('aaaa','ffff')




select * from [dbo].[proudcts]
select * from [dbo].[sales_order]


create view v_sale_order
as
select p.pid,p.panme,p.price,s.qty
from proudcts as p  left join sales_order as s
	on p.pid = s.oid 


--will not work
insert into v_sale_order
values(100,'test',300,10)

--will not work
insert into v_sale_order(pid,panme,price,qty)
values(100,'test',300,10)

--will work 
insert into v_sale_order(pid,panme,price)
values(100,'test',30)


----

CREATE FUNCTION dbo.income_tax
(
	@basic as int
)
RETURNS int
AS
BEGIN

	declare @tax as int = 0,
			@msal as int =0,
			@hra as int =0,
			@da as int = 0,
			@ysal as int = 0


	set @hra = @basic *.50
	set @da = @basic *.20

	set @msal = @basic+ @hra+@da 
	set @ysal = @msal*12


	if @ysal <5000000 
	begin
		set @tax = 0
	end 
	else if @ysal <1000000 
	begin

		set @tax = (@ysal- 500000)*.20
	end
	else
	begin
		set @tax = (@ysal- 500000)*.30
	end 


	-- Return the result of the function
	RETURN @tax 

END
GO



select * from employee
select eid,fname , lname , slry , dbo.income_tax(slry) as tax 
from employee

select dbo.income_tax(3344555)

select getdate()

select left('askfhsjg ghss',3)


select *  from  dbo.multi_value(1)

----
-- ================================================
-- Template generated from Template Explorer using:
-- Create Inline Function (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the function.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
alter FUNCTION dbo.multi_value
(	
@id as int
)
RETURNS TABLE 
AS
RETURN 
	(

	
			-- Add the SELECT statement with parameter references here
			--SELECT *  from employee  where eid > @id 
			select * from employee
	)






