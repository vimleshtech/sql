
-- create database 
create database learn    --one time for every applcation 

--change database 
use learn 

--create new table 
create table employee			--one time 
(
eid			int,
fname		varchar(30),
lname		varchar(30),
email		varchar(50),
mobno		varchar(15),
gender		varchar(1),
dob			date,
salary		int
)

--insert or save data 
insert into employee(eid,fname,lname,email,gender,dob,salary)
values(1,'raman','sinha','raman@gmail.con','m','1990-11-10',56000)


--insert multiple rows
insert into employee(eid,fname,lname,email,gender,dob,salary)
values(2,'nitisha','sinha','nitisha@gmail.con','f','1992-12-07',66000),
(3,'jatin','sinha','jatin@gmail.con','m','1988-03-10',42000),
(4,'ridhi','sharma','ridhi@gmail.con','f','1993-07-20',60000),
(5,'monika','pandey','monika@gmail.con','f','1991-03-11',96000)


-- date : yyyy-mm-dd

--view table,  * : show all columns 
select * from employee 


--show selected columns
select fname,lname,salary from employee

--show selected rows 
select * from employee where eid = 3

select * from employee where eid > 3

select * from employee where eid < 3

select * from employee where gender ='m'

select * from employee where gender ='f'

--show selected columns and selected rows
select fname,lname,dob,gender from employee where eid = 2


--delete row 
select * from employee

--delete all rows 
-- delete from employee  

--delete selected rows
delete from employee where eid  = 4

--drop column
alter table employee 
drop column mobno 


--update data 
update employee 
set lname ='wadhawa' 
where eid  =3



