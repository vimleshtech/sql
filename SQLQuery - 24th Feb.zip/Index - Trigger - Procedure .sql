/*

Q. WAS to alow pwd when this will contain at least one number , one char and length should be between 8 to 13 


Today's Topics
===========================
-> Index
-> Trigger 
-> Procedure
-> performance 

Q. Copy one database table to another table
Q. 
	 1 2 3 4 5 

	 1 2 4 




*/

select * into abcd..emp from abc..emp 


--
select * from tabl1 where id not in (select id from table2) 

--
select * from tbl1 left join tbl2 
	on tbl1.id = tbl2.id 
where tbl2.id is null



/*
-> Index : to store data in sorted/arrange order 
There are following types of index:
	-Cluster index  : Physically sorted (can be single on a table)
	-Non-Cluster index: virtually sorted 


Create index
Drop index 
Rebuild
Reorganize 

*/


create table test
(
id int,
name varchar(100)
)



insert into test
values(1,'raman'),
(20,'raman'),
(30,'raman'),
(4,'raman'),
(5,'raman')


insert into test
values(10,'jaitn')


select * from test 

 



create table test2
(
id int primary key,
name varchar(100)
)

insert into test2
values(1,'raman'),
(20,'raman'),
(30,'raman'),
(4,'raman'),
(5,'raman')


insert into test2
values(50,'jaitn')

select * from test2


sp_help test2


alter table test2
drop constraint PK__test2__3213E83F999B2B52 



--add non-cluster index
create index ix_test2_name 
on test2(name)

create index ix_test2_name 
on test2(name,dob)


create index ix_test1_name1
on test(id,name)


/*
-> Trigger  : is kind procedure(set sql statement / command) 
 which will execute automatically when any DML (insert, udpate, delete) will run on a table 

 There are following types pro trigger:
	-instead of (before)
			insert
			update
			delete

	-after 
			insert
			update
			delete 
There are following virtual table/magic table:
	-inserted			: for insert, update 
	-deleted			: for delete, update 
		
*NOTE : TRIGGER WILL CREATE ON BASE TABLE 


==================
users
uid  name email  pwd  
1   raman ab@gm  34 

*/

create table users
(id int identity(1,1), name varchar(30) not null,
 emailid  varchar(100) primary key,
 pwd      varchar(15) not null
 )


insert into users 
values('nitin','nitin@gmail.com','pwd123')


insert into users 
values('jatin','jatin@gmail.com','jai@123')


select * from users 

update users 
set pwd ='alpha@12'
where id  =1

select * from users_log
where emailid='jatin@gmail.com'
order by time_stamp desc



create table users_log
(name varchar(30) not null,
 emailid  varchar(100),
 pwd      varchar(15) not null,
 time_stamp datetime default getdate(),
 action_type   char(1)    
 )


 CREATE TRIGGER TRG_UPDATE_LOG  
 ON users
 AFTER UPDATE
 AS
 BEGIN

		INSERT INTO users_log(NAME,emailid,pwd,action_type)
		SELECT NAME,emailid,PWD,'U' FROM DELETED 



 END


 udpate_pwd 'jatin@gmail.com','abcd@124'



create procedure udpate_pwd (@emailid varchar(30), @newpwd varchar(15))
AS
BEGIN

					if   exists ( select * from 
								 (select top 3 * from users_log
								 where emailid = @emailid
								 order by time_stamp desc
								 ) T
							where pwd = @newpwd
						)
					begin

							select 'pwd cannot be change..... ' as msg
					end
					else 
					begin
								update users 
								set pwd = @newpwd
								where emailid =@emailid

					end


END




