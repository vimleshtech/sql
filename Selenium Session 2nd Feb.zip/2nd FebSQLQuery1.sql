
select * from employee 
select * from salary 


--inner join 
select e.EID,e.fname,e.lname,s.BASIC,s.DA,s.HRA  --3
from employee  as e inner join salary as s   --1
	on e.eid = s.eid						 --2


select e.EID,e.fname,e.lname,s.BASIC,s.DA,s.HRA  --3
from employee  as e join salary as s   --1
	on e.eid = s.eid						 --2


select e.EID,e.fname,e.lname,s.BASIC,s.DA,s.HRA  --3
from employee  as e join salary as s   --1
	on e.eid = s.eid						 --2
	  and s.basic > 20000

--outer join

select e.EID,e.fname,e.lname,s.BASIC,s.DA,s.HRA  --3
from employee  as e full outer join salary as s   --1
	on e.eid = s.eid						 --2
	  and s.basic > 20000

--left join

select e.EID,e.fname,e.lname,s.BASIC,s.DA,s.HRA  --3
from employee  as e left  join salary as s   --1
	on e.eid = s.eid						 --2
	  and s.basic > 20000


--right join


select e.EID,e.fname,e.lname,s.BASIC,s.DA,s.HRA  --3
from employee  as e right  join salary as s   --1
	on e.eid = s.eid						 --2


select e.EID,e.fname,e.lname,s.BASIC,s.DA,s.HRA.d.name  --3
from employee  as e inner  join salary as s   --1
			on e.eid = s.eid						 --2
	inner join department as d 
			on e.did = d.id 



--store in new table
select e.EID,e.fname,e.lname,s.BASIC,s.DA,s.HRA  
into output_tbl
from employee  as e left  join salary as s   --1
	on e.eid = s.eid						 --2
	  and s.basic > 20000

select * from output_tbl

